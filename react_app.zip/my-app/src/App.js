import logo from './logo.svg';
import './App.css';
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import Home from './Components/Home';
import Login from './Components/Login';
import Sighup from './Components/Sighup';
import 'react-toastify/dist/ReactToastify.css';
import { useState } from 'react';
function App() {
  const [islogin, setIslogin] = useState(false)
  const [user, setUser] = useState(null)
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route index element={<Login setUser={setUser} />} />
          <Route path="/home" element={<Home user={user} setUser={setUser} />} />
          <Route path="/signup" element={<Sighup setUser={setUser} />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
