import axios from "axios";

const checkLogin = async token => {
    const res = await axios.post('http://localhost:8000/auth/checklogin', {
        token
    });
    return res.data
}

const login = async (email, password) => {
    const res = await axios.post('http://localhost:8000/auth/login', {
        loginCredentials: email, password
    });
    return res.data
}


const signup = async ({ email, password, userName, fullName }) => {
    const res = await axios.post('http://localhost:8000/auth/sighup', {
        email, password, userName, fullName
    });
    return res.data
}

export default { checkLogin, login, signup }