import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import authController from '../controllers/authController'
import { ToastContainer, toast } from 'react-toastify';

const Login = ({ setUser }) => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    const login = async () => {
        const res = await authController.login(email, password);
        if (res.error) {
            return toast.warn(res.msg)
        }
        setUser(res.data)
        toast.success(res.msg)
        localStorage.setItem("token", res.data.token);
        navigate("/home");
    }

    const checkLogin = async () => {
        const token = localStorage.getItem("token")
        if (token != undefined) {
            const res = await authController.checkLogin(token);
            if (res.error) {
                return toast.warn(res.msg)
            }
            setUser(res.data)
            return navigate("/home");
        }
    }

    useEffect(() => {
        checkLogin();
    }, [])

    return (
        <div>
            <ToastContainer />
            <h2>Username/email</h2>
            <input type="text" value={email} onChange={e => setEmail(e.target.value)} />

            <h2>Password</h2>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} />

            <button onClick={() => login()}>Login</button>
        </div>
    )
}

export default Login