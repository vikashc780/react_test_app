import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
import authController from '../controllers/authController';
import { ToastContainer, toast } from 'react-toastify';
const Home = ({ user, setUser }) => {
    console.log('user', user)
    const navigate = useNavigate();
    const checkLogin = async () => {
        const token = localStorage.getItem("token")
        if (token) {
            const res = await authController.checkLogin(token);
            if (res.error) {
                toast.warn(res.msg)
                return navigate("/");
            }
            setUser(res.data)
            return;
        }
        return navigate("/");
    }

    const logOut = () => {
        localStorage.removeItem("token")
        navigate("/")
    }
    useEffect(() => {
        if (!user)
            checkLogin();
    }, [])

    return (
        <div>Home
            <ToastContainer />
            {user &&
                <h1>{user.fullName}</h1>
            }
            <button onClick={logOut}>Log Out</button>
        </div>
    )
}

export default Home