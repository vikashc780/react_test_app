import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import authController from '../controllers/authController';
import { ToastContainer, toast } from 'react-toastify';

const Sighup = ({ setUser }) => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("");
    const [userName, setUserName] = useState("");
    const [fullName, setFullName] = useState("");

    const signup = async () => {
        const res = await authController.signup({ email, password, userName, fullName });
        console.log('res', res)
        if (res.error) {
            toast.warn(res.msg)
            return
        }
        toast.success("Login successfully plz login with you credentials")
        navigate("/")
    }
    return (
        <div>
            <ToastContainer />
            <h2>Username</h2>
            <input type="text" value={userName} onChange={e => setUserName(e.target.value)} />
            <h2>Email</h2>
            <input type="text" value={email} onChange={e => setEmail(e.target.value)} />
            <h2>Full name</h2>
            <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} />

            <h2>Password</h2>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} />

            <button onClick={() => signup()}>Login</button>
        </div>
    )
}

export default Sighup